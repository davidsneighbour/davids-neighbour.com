## Version 1.0.0 (02 dec 2019)
- Initial template
- Hugo version 0.62.2
- Bootstrap version 4.4.1

## Version 1.1.0 (17 may 2020)
- About and Contact page redesign
- Added Missing page
- Modified footer

## Version 1.2.0 (3 jun 2020)
- Added post slider
- improve google analytics
- Added opengraph template
- Forestry make esier to use
- Fix taxonomy filter
- Redesign author page

## Version 1.2.1 (16 sep 2020)
- Added demo homepage
- Added multilingual navigation

## Version 1.2.2 (10 oct 2020)
- Fixed search result post date

## Version 1.2.3 (19 oct 2020)
- Optimize page speed