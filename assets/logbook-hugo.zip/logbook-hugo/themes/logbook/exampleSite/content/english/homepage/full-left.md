---
title: "Homepage Full Left"
layout: "full" # layout value (full or list)
sidebar: "left" # sidebar value (left,right or false)
---