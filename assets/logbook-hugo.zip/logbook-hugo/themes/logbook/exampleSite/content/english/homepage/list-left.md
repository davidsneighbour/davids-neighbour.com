---
title: "Homepage List Left"
layout: "list" # layout value (full or list)
sidebar: "left" # sidebar value (left,right or false)
---