---
title: "Homepage Full Right"
layout: "full" # layout value (full or list)
sidebar: "right" # sidebar value (left,right or false)
---