---
title: "Homepage Full"
layout: "full" # layout value (full or list)
sidebar: "false" # sidebar value (left,right or false)
---